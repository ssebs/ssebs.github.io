INSTALL INSTRUCTIONS
^^^^^^^^^^^^^^^^^^^^
1) Double click the 'DoubleClick' file and press okay
2) Right Click on 'Main' and select 'void main(String[]args)'
3) Press 'Ok'
4) Click on screen after console appears
5) 'W', 'S', 'UP', and 'DOWN' are the controls

Game made by Sebastian Safari, Matt Sanfilippo, at ssebs 

http://ssebs.com/

email at ssebs@ssebs.com