(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24.95,
	color: "#FFFFFF",
	manifest: []
};



// symbols:



(lib.Tween13 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("Made by ssebs.", "39px 'Verdana'", "#CC00FF");
	this.text.lineHeight = 41;
	this.text.lineWidth = 324;
	this.text.setTransform(-164,-29.5);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-164,-29.5,328.1,59);


(lib.Tween12 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("Made by ssebs.", "39px 'Verdana'", "#CC00FF");
	this.text.lineHeight = 41;
	this.text.lineWidth = 324;
	this.text.setTransform(-164,-29.5);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-164,-29.5,328.1,59);


(lib.Tween11 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("Made by ssebs.", "39px 'Verdana'", "#CC00FF");
	this.text.lineHeight = 41;
	this.text.lineWidth = 324;
	this.text.setTransform(-164,-29.5);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-164,-29.5,328.1,59);


(lib.Tween10 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("Made by ssebs.", "39px 'Verdana'", "#CC00FF");
	this.text.lineHeight = 41;
	this.text.lineWidth = 324;
	this.text.setTransform(-164,-29.5);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-164,-29.5,328.1,59);


(lib.thingy = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AjxGSQAoAaA5AJQABgBACgBQAFACAEACQAZADAeAAQFvAABumjQA3jRgSjhAkglpIAAgBQgIgDgKgDIhIAAQgzAlgIAMQgEAHAAAiQAAAKAPATQAPASAAAfIgEARIA6AAAkBi3IAlAAQgBgEAAgGQAAgMAUgWQAUgXAAgHQAAgNgUgUQgbgXgNgNIAAgJQgCgBgCAAAiNmvQgDAIgDADQgHAHgRAAQgDAAgEgBQgbARgVAZQARAIASALQgBADAAACQAYAFANATQAOAVAAAtQAAAcgKAYQgGAPgIAIIAYAAQAHACAIAAQAFACAAAQQAAAQgFADQgBABgOAAIisABQAAABAAABAD1mvIi0AAQgZgGgXgEQgBAvgBAhQgBAAgFADQgGADgEACQgLgkAAgwAEdmvIgEAAAlFkbQAAgBABgCQACgGACgGAlajJQAAgBAAgC");
	this.shape.setTransform(10.2,-76.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA6GuQgBgLAAgfQAAhGAEgWQALhCAqAOQA3hoAPiiIABgfQARAOAUALIgDAcQgdDshlDfQgCADgKACQgPgGgEgcgAjYhSQgFgNAAgFQAAhwCri3QAigkAgggIBIAAIgVATQhOBIgtAxQiGCQAJBxIgGAEQgHAFgHADQgJgLgGgRg");
	this.shape_1.setTransform(-36.7,-28.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ADPa8IAAgCQgsiRhHkFQg4jHgShLQgXBxhTC0QhWC4heCeQgNgFgIgIQBZiwA/iQQCAkkABhhQAAjJgZi+IgJhOQh2A+htAuQjKBTh2AAQgPAAgGgEIgIgJIE7h6QCfg+BhgsQgMieAAjXQABgkgJhGQgKhZgBgeQgGhUAQgsQgqgJghgRQgUgLgRgNQg3gtgVhMQgPg5AFhIIAIhGIgChaIgRAAIhIgBIj0gHIABABQADAGAAASQAAAbgZAtQgcAygbAAQgxAAgKgwIAAgzQAAgvACgNIABgEQgegHgOgWQgKgRAAgVQABgtAegTQAugcCPgNIAAgDIADAAQAFAAAEgCIC9AAQgQgOgFgeIAAg4QABhMAvgjQA5gqBtAtQAXgeAegUQgfgsgShxQgKg6gFhFIgCg5QgBhdAwgeQArgcA7AlQA9AmApBVQAuBgABB5IgBBCQAdADAgAGQBYgBBEABQAVgyAmh5QAlh6AqhDQBxiwBnBaQAoAiAaBBQAXA9AAA3QAABDguAuQhVBIhOBTQAGAEACAGQACAEgBAYIAACpQgICpgnCHQh6GkmCAAQgXAAgUgCIAAK5IACAIQA1gaAfgTQBlhACuiOQBZhIBjhSQAGACAIAAQAFACABAQQAAAsiEBqQh+Bni8BwQg8Ajg4AgQAKBQALB0QASC8ACBUIABAAQAlCkBBDdIB1GBIgEANQgEAHgQAAQgQAAgCgDgAgelHQAaADAbAAQFxAABumjQA3jTgRjhIAAAAIABgDIAAgMIgCgeIgCgFIADAAIAAgCQgBgTAggaQASgPAzgjQBjhKABhPQAEg4gQgwQgihghrAAQgqAAgfA4QgXAngcBbQgnCAgJAYQgVA6gYAjIADAAIgCADQgSAXgGAXIi0AAQgZgHgXgEIgCBRIgGADIgLAFQgLgkAAgwQAEgDAAgJIgCgVQABgOgBgIIAAAAIABgHQANh8AAgTQgChOgsg0Qg2hBh+gsQgNASgDAiQgBAMgBAoQABBuAPBDQAQBOAoA3IADgBIAAAAQABAGACACIAKAPQACAEAKAKQgDAIgDADQgHAHgQAAIgIgBQgaARgWAYIAkAUIgCAFQAYAFANATQAOAVAAAtQABAcgLAYQgGAPgIAIIAYAAQAHACAIAAQAGACgBAQQABAQgGADIgPABIisABIAAACQgLgCgPAAQgSgBgMACIkhADIhrAXQg7ANgRAQQAOARATAMIAHAEIABAAIADAEQAIAIAHAMIADgBQAkgECOAIIDYACIAHABIATgBIAPgCQAKADAOAAIAGgBIBJABIAKABQA+AGBVAQQBxAQDQALQAOAJADAJQAEAIAAAUQAAA2hrA3QhsA3huAAQgjAAgIgjIAAgmQAAgsACgPQAGgpAYgUQgogKhpgPIhigBIAABcQAAAHgHA5QgEA/AMAyQAMAwAcAiQARAUAWAPQAoAaA5AJIADgCIAJAEgABBrEQgRAHgGAVIgMApIAABBQBFAIBggpQBWgkAmgpIAAgPIhQgKIAAAIQAAAPhBAlQhBAmgdAAQgSAAgJgEQgHgCgHgHQAMgcBNgjQAlgRAbgJQglgDgbAAQgtAAgSAIgAqxqTIAGAFQAcgNAPgeQAQgegEggIg9gCgAjNuxIApAAQAGgCACgDIABgBIAlAAIgBgKQAAgMAVgWQATgXABgHQgBgNgTgUQgbgXgOgNIAAgJIgEgCQgCgHgMgDIgJgHQgOgLgGADIAAAAIgRgGIhJAAQgzAlgIAMQgDAHAAAiQgBAKAQATQAPASgBAfIgEARIA6AAQAEAFAMAAIAdgCIAFADgADlt7IhngfQg5gRAAggQABgkAfgrQAfgqAwgdQCLgLAmAnQANAMABAQQAAAJgBAIQAAAXgUA5QgVBAgUANgACHwAQgSAWAAAfQAAALAgAFQA4AKAbAJIBBAAQAOgJAKgjQAJgfgBgeQAAgRgMgGQgcgOhhgBIg5A3gAj0vMIAAACIABABIgBAAIAAgDgAC3vPQgHgCgGgHQAPgWAVgKQALgHAWgIIAPAEQAGADAAAQQgBAXgRAJQgLAFgVAAQgSAAgJgEgAkMweQAIgNAJgFIAPgEIAHAPQgEAOgPAGQgNgFgHgIgAjeweIAEgMIAAACIABAGIgGAHIABgDgAF/yvIACgCIACACg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BC7232").s().p("AgfKiIgIgFIgEADQg5gJgngaQgXgPgQgUQgcgigMgwQgNgyAFhAQAHg4AAgHIAAhcIBiABQBpAPAoAKQgYAUgGAoQgDAPAAAtIABAlQAHAkAjAAQBuAABsg3QBrg3AAg2QAAgUgDgIQgEgJgNgJQjRgLhwgQQhVgQg+gHIgKgBIhKAAIgFAAQgPAAgJgCIgPACIgTAAIgIAAIjXgCQiOgIgkAEIgEABQgHgMgHgIIgEgEIAAAAIgHgFQgTgMgOgQQAQgQA7gNIBsgYIEggCQANgCASABQAOAAALACIABgCICsgBIAPgBQAFgDAAgQQAAgQgFgCQgIAAgHgDIgYAAQAIgIAGgOQAKgYAAgbQAAgtgOgUQgNgTgZgGIACgFIgjgTQAVgZAbgQIAHABQARAAAHgIQADgDACgHQgKgKgCgFIgKgOQgCgCAAgGIAAAAIgDABQgog3gRhOQgPhDAAhvQAAgnACgMQADgiANgSQB+AsA2BBQAsA0ACBOQAAATgNB7IgBAIIgBAAQACAIgCAOIADAVQAAAJgFACQAAAxALAjIAMgEIAGgDIABhRQAYAEAZAHIC0AAQAFgXATgXIACgDIgDAAQAXgjAWg6QAJgZAnh/QAbhbAXgnQAgg4AqAAQBrAAAhBfQARAxgFA4QAABPhkBKQgyAjgSAPQggAaAAASIAAADIgCgBIABAFIACAfIAAAMIgBADIAAAAQASDfg3DSQhuGklxAAQgcAAgagDgACzh3QgvAegfApQggAsAAAhQAAAgA5ASIBnAfIBQAAQATgNAWhAQATg3AAgXQACgJAAgIQgBgRgNgLQgfgfhcAAQgZAAgeACgAF/jEIAEAAIgCgCIgCACg");
	this.shape_3.setTransform(0,-100.3);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-78,-172.7,156,345.4);


(lib.ball = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AHRAAQAADAiJCIQiICJjAAAQi/AAiJiJQiIiIAAjAQAAi/CIiJQBJhIBYgiQBOgeBZAAQBaAABOAeQBYAiBIBIQCJCJAAC/g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AlIFIQiIiIAAjAQAAi/CIiJQBJhIBYghQBOgfBZAAQBaAABOAfQBYAhBIBIQCJCJAAC/QAADAiJCIQiICJjAAAQi/AAiJiJg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-47.5,-47.5,95,95);


(lib.rat = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.thingy("synched",0);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-78,-172.7,156,345.4);


// stage content:
(lib._2ndAnimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Thing
	this.instance = new lib.rat("synched",0);
	this.instance.setTransform(83,206.3);

	this.instance_1 = new lib.thingy("synched",0);
	this.instance_1.setTransform(472,206.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,x:472},9).wait(62));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},9).to({startPosition:0},8).to({startPosition:0},44).wait(10));

	// Ball
	this.instance_2 = new lib.ball("synched",0);
	this.instance_2.setTransform(-33,36);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(17).to({_off:false},0).to({x:231.1,y:345.1},8).to({x:382.1,y:227.1},7).to({x:270.1,y:342.1},8).to({x:46.5,y:346.1},12).to({_off:true},1).wait(18));

	// Text 
	this.instance_3 = new lib.Tween10("synched",0);
	this.instance_3.setTransform(179,112.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween11("synched",0);
	this.instance_4.setTransform(179,245.5);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween12("synched",0);
	this.instance_5.setTransform(169,29.5);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween13("synched",0);
	this.instance_6.setTransform(179,112.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},53).to({state:[{t:this.instance_4}]},6).to({state:[{t:this.instance_5}]},6).to({state:[{t:this.instance_6}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(53).to({_off:false},0).to({_off:true,y:245.5},6).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({_off:false},6).to({_off:true,x:169,y:29.5},6).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(59).to({_off:false},6).to({_off:true,x:179,y:112.5},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(280,233.6,156,345.4);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;